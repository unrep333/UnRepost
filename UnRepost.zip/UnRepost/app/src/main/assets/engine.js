(function(){
if(window.__UR)return;
var S=window.__UR={listUrl:null,delUrl:null,run:false,paused:false,removed:0,skipped:{},pending:{}};
var sleep=function(ms){return new Promise(function(r){setTimeout(r,ms)})};
var jit=function(a,b){return a+Math.random()*(b-a)};
function send(s,m){try{Android.post(JSON.stringify({s:s,removed:S.removed,skipped:Object.keys(S.skipped).length,msg:m||''}))}catch(e){}}
function check(){if(!S.run)send(S.listUrl&&S.delUrl?'ready':S.listUrl?'learn':'idle')}

// Запоминаем настоящие подписанные запросы, которые делает сама страница TikTok.
try{performance.setResourceTimingBufferSize(5000)}catch(e){}
try{new PerformanceObserver(function(l){
  l.getEntries().forEach(function(e){
    if(e.name.indexOf('/api/repost/item_list')>-1)S.listUrl=e.name;
    else if(e.name.indexOf('/tiktok/v1/upvote/delete')>-1)S.delUrl=e.name;
  });
  check();
}).observe({type:'resource',buffered:true})}catch(e){}

async function list(cur){
  var u=new URL(S.listUrl);u.searchParams.set('cursor',cur);u.searchParams.set('count','30');
  var r=await fetch(u.toString(),{credentials:'include'});
  if(r.status!==200)return{err:r.status};
  var j=await r.json();
  if(j.status_code!==undefined&&j.status_code!==0)return{err:'code '+j.status_code};
  return{items:(j.itemList||[]).map(function(x){return x.id}),cursor:String(j.cursor||'0'),more:!!j.hasMore};
}
async function del(id){
  var u=new URL(S.delUrl);u.searchParams.set('item_id',id);
  var r=await fetch(u.toString(),{method:'POST',credentials:'include',headers:{'content-type':'application/x-www-form-urlencoded'}});
  if(r.status===429)return'rate';
  var j={};try{j=await r.json()}catch(e){}
  return r.status===200&&j.status_code===0?'ok':'fail';
}
async function gate(){while(S.paused&&S.run)await sleep(400)}
var safeDel=function(id){return del(id).catch(function(){return'fail'})};

S.pause=function(){S.paused=true;send('paused')};
S.resume=function(){S.paused=false;send('running')};
S.start=async function(){
  if(S.run||!S.listUrl||!S.delUrl)return;
  S.run=true;S.paused=false;
  var cur='0',empty=0,back=20000,bad=0,n=0;
  send('running');
  while(S.run){
    await gate();
    var p;try{p=await list(cur)}catch(e){p={err:String(e)}}
    if(p.err){
      // пустой/ошибочный ответ ≠ «репостов нет»: это мягкая блокировка или сеть
      if(++bad>8){S.run=false;send('error','TikTok не отвечает или сессия истекла. Войдите снова.');return}
      send('running','Ограничение TikTok, жду '+Math.round(back/1000)+' с');
      await sleep(back);back=Math.min(back*2,300000);continue;
    }
    bad=0;back=20000;
    // проверка: то, что мы «удалили», не должно вернуться в списке
    p.items.forEach(function(id){if(S.pending[id]){S.skipped[id]=1;S.removed--}});
    S.pending={};
    var fresh=p.items.filter(function(id){return!S.skipped[id]});
    if(!fresh.length){
      if(p.more&&p.items.length){cur=p.cursor;continue}
      if(++empty>=3)break; // конец подтверждаем три раза
      await sleep(4000);cur='0';continue;
    }
    empty=0;
    for(var i=0;i<fresh.length&&S.run;i++){
      await gate();
      var id=fresh[i],res=await safeDel(id),t=0;
      while(res!=='ok'&&t<2&&S.run){await sleep(res==='rate'?60000:jit(2000,4000));res=await safeDel(id);t++}
      if(res==='ok'){
        S.removed++;S.pending[id]=1;
        if(++n%25===0){send('running','Короткая пауза…');await sleep(jit(8000,15000))}else send('running');
      }else if(res==='rate'){
        send('running','Лимит TikTok, жду…');await sleep(back);back=Math.min(back*2,300000);break;
      }else S.skipped[id]=1;
      await sleep(jit(700,1600));
    }
    await sleep(2500);cur='0'; // всегда снова берём начало списка
  }
  S.run=false;send('done');
};
check();
})();
