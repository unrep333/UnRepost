package app.unrepost

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.os.*

/** Держит процесс живым в фоне: уведомление + wake lock. Сама работа идёт в WebView. */
class KeepAliveService : Service() {
    private var wl: PowerManager.WakeLock? = null
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val n = note(this, "Удаляю репосты…")
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else startForeground(1, n)
        if (wl == null) wl = getSystemService(PowerManager::class.java)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "unrepost:run").apply { acquire(8 * 3600_000L) }
        return START_NOT_STICKY
    }

    override fun onDestroy() { wl?.release(); super.onDestroy() }

    companion object {
        fun note(c: Context, text: String): Notification {
            c.getSystemService(NotificationManager::class.java)
                .createNotificationChannel(NotificationChannel("ur", "UnRepost", NotificationManager.IMPORTANCE_LOW))
            val pi = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            return Notification.Builder(c, "ur").setContentTitle("UnRepost").setContentText(text)
                .setSmallIcon(android.R.drawable.stat_notify_sync).setContentIntent(pi).setOngoing(true).build()
        }
    }
}
