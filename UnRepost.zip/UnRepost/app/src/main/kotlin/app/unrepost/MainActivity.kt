package app.unrepost

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.NotificationManager
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.webkit.*
import android.widget.*
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var num: TextView
    private lateinit var info: TextView
    private lateinit var btn: Button
    private var st = "idle"
    private val engine by lazy { assets.open("engine.js").bufferedReader().readText() }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        val d = resources.displayMetrics.density
        val dp = { v: Int -> (v * d).toInt() }

        web = WebView(this)
        web.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true
            useWideViewPort = true; loadWithOverviewMode = true
            setSupportZoom(true); builtInZoomControls = true; displayZoomControls = false
            // десктопная версия TikTok: в ней есть вкладка «Репосты»
            userAgentString = WebSettings.getDefaultUserAgent(this@MainActivity)
                .replace(Regex("\\(Linux; Android[^)]*\\)"), "(X11; Linux x86_64)").replace(" Mobile", "")
        }
        CookieManager.getInstance().apply { setAcceptCookie(true); setAcceptThirdPartyCookies(web, true) }
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView, u: String) {
                if (u.contains("tiktok.com")) v.evaluateJavascript(engine, null)
            }
        }

        num = TextView(this).apply { textSize = 44f; setTextColor(Color.WHITE); gravity = Gravity.CENTER }
        info = TextView(this).apply { textSize = 14f; setTextColor(0xFFA0A0A0.toInt()); gravity = Gravity.CENTER }
        btn = Button(this).apply {
            isAllCaps = false; setTextColor(Color.WHITE); textSize = 16f
            background = GradientDrawable().apply { setColor(0xFFFE2C55.toInt()); cornerRadius = dp(26).toFloat() }
            setOnClickListener { onBtn() }
        }
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFF121212.toInt())
            setPadding(dp(20), dp(12), dp(20), dp(16))
            addView(num); addView(info)
            addView(btn, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(12) })
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(web, LinearLayout.LayoutParams(-1, 0, 1f)); addView(panel)
        })
        render("idle", 0, 0, "")
        web.loadUrl("https://www.tiktok.com/login")
    }

    private fun js(code: String) = web.evaluateJavascript("window.__UR && $code", null)

    private fun onBtn() {
        when (st) {
            "ready" -> { startForegroundService(Intent(this, KeepAliveService::class.java)); js("__UR.start()") }
            "running" -> js("__UR.pause()")
            "paused" -> js("__UR.resume()")
        }
    }

    private fun render(s: String, n: Int, sk: Int, msg: String) {
        st = s; num.text = n.toString()
        val (text, label) = when (s) {
            "idle" -> "Войдите в TikTok, откройте свой профиль → «Репосты»" to ""
            "learn" -> "Один раз удалите любой репост вручную — дальше я сам" to ""
            "ready" -> "Готово к запуску" to "Старт"
            "running" -> msg.ifEmpty { "Удаляю репосты…" } to "Пауза"
            "paused" -> "На паузе" to "Продолжить"
            "done" -> "Готово. Не удалось удалить: $sk" to ""
            else -> msg.ifEmpty { "Ошибка" } to ""
        }
        info.text = text; btn.text = label
        btn.visibility = if (label.isEmpty()) View.GONE else View.VISIBLE
        if (s == "running") {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            getSystemService(NotificationManager::class.java).notify(1, KeepAliveService.note(this, "Удалено: $n"))
        } else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (s == "done" || s == "error") stopService(Intent(this, KeepAliveService::class.java))
    }

    inner class Bridge {
        @JavascriptInterface
        fun post(j: String) = runOnUiThread {
            val o = JSONObject(j)
            render(o.getString("s"), o.optInt("removed"), o.optInt("skipped"), o.optString("msg"))
        }
    }

    @Deprecated("back")
    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }
    override fun onDestroy() { web.destroy(); super.onDestroy() }
}
